# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-PackageHomePage: https://github.com/noon92/pushraker
# SPDX-FileCopyrightText: Copyright (c) 2026 @noon92

"""python -m pushraker install|uninstall|status: wire the package into a
Moonraker + Klipper installation.

  install     put the component shim into Moonraker's components folder,
              enable [pushraker] in Moonraker's config, include
              the Klipper macro file, and (once) move settings over from
              an INI section such as the Snapmaker U1 extended firmware's
              extended2.cfg [notifications]
  uninstall   take those out again (the settings and secrets stay unless
              --purge)
  status      say what is in place

Paths default to a standard printer_data layout under the running user's
home (~/moonraker, ~/printer_data); the Snapmaker U1 extended firmware's
harness passes its own, and install.py (the one-line install over SSH)
passes what it found in the running Moonraker.
"""

from __future__ import annotations
import argparse
import os
import shutil
import sys
from typing import List, Optional

from . import __version__
from . import settings as cfgmod

SHIM_NAME = "pushraker.py"
SECTION = "pushraker"
# What 0.1.x installed under the old component name: replaced on install
OLD_SHIM_NAME = "push_notifications.py"
OLD_SECTION = "push_notifications"
MOONRAKER_INCLUDE = "pushraker.cfg"
KLIPPER_INCLUDE = "pushraker.cfg"
SHIM = '''# pushraker: Moonraker loads components from this folder; this file hands
# over to the installed package. Written by `python -m pushraker install`.
import sys
for _p in {paths!r}:
    if _p and _p not in sys.path:
        sys.path.append(_p)
from pushraker.component import load_component  # noqa: E402,F401
'''


def home(sub: str) -> str:
    return os.path.join(os.path.expanduser("~"), sub)


def parse(argv: List[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="python -m pushraker",
                                description=__doc__.split("\n\n")[0])
    p.add_argument("command", choices=["install", "uninstall", "status"])
    p.add_argument("--moonraker-dir", default=home("moonraker"),
                   help="Moonraker's source directory: holds "
                        "moonraker/components (packaged layout) or "
                        "components (older, flat layout)")
    p.add_argument("--components-dir", default=None,
                   help="Moonraker's components folder itself (default: "
                        "found under --moonraker-dir)")
    p.add_argument("--data-dir", default=home("printer_data"),
                   help="printer_data (config/, the secrets file lives here)")
    p.add_argument("--moonraker-conf", default=None,
                   help="moonraker.conf (default: <data-dir>/config/moonraker.conf)")
    p.add_argument("--moonraker-include-dir", default=None,
                   help="a directory moonraker.conf already includes: the "
                        "[pushraker] section is written there as "
                        "pushraker.cfg instead of into moonraker.conf")
    p.add_argument("--printer-cfg", default=None,
                   help="printer.cfg (default: <data-dir>/config/printer.cfg)")
    p.add_argument("--klipper-include-dir", default=None,
                   help="a directory printer.cfg already includes: the macro "
                        "file is copied there instead of being included from "
                        "printer.cfg")
    p.add_argument("--site-packages", action="append", default=[],
                   help="extra sys.path entries for the shim (the package's "
                        "venv, when Moonraker's Python can't see it)")
    p.add_argument("--name", default="Printer",
                   help="the printer's default name in notifications")
    p.add_argument("--error-index-url", default="",
                   help="the printer maker's error-code index, linked from "
                        "fault notifications")
    p.add_argument("--import-ini", nargs=2, metavar=("FILE", "SECTION"),
                   help="settings to move into pushraker.conf when it doesn't "
                        "exist yet (e.g. extended2.cfg notifications)")
    p.add_argument("--import-secrets", nargs=2, metavar=("FILE", "SECTION"),
                   help="the secrets that go with --import-ini (e.g. "
                        "moonraker.secrets notifications)")
    p.add_argument("--no-klipper", action="store_true",
                   help="install: leave Klipper's config alone (no macro "
                        "file, no include in printer.cfg)")
    p.add_argument("--backup", default="", metavar="SUFFIX",
                   help="copy moonraker.conf and printer.cfg to "
                        "<file><SUFFIX> before their first change (an "
                        "existing copy is kept)")
    p.add_argument("--purge", action="store_true",
                   help="uninstall: also remove pushraker.conf and the secrets")
    p.add_argument("--owner", default="",
                   help="user[:group] the written files belong to (default: "
                        "whoever owns the directory they go into)")
    return p.parse_args(argv)


def write(path: str, text: str, mode: int = 0o644,
          owner: str = "") -> bool:
    """Write if different; returns whether it changed. Files take the
    owner of their directory unless --owner says otherwise."""
    try:
        with open(path, encoding="utf-8") as f:
            if f.read() == text:
                return False
    except (OSError, UnicodeDecodeError):
        pass
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
    os.chmod(tmp, mode)
    chown(tmp, owner, os.path.dirname(path))
    os.replace(tmp, path)
    return True


def chown(path: str, owner: str, like: str) -> None:
    try:
        if owner:
            import pwd
            import grp
            user, _, group = owner.partition(":")
            uid = pwd.getpwnam(user).pw_uid
            gid = grp.getgrnam(group).gr_gid if group else \
                pwd.getpwnam(user).pw_gid
        else:
            st = os.stat(like)
            uid, gid = st.st_uid, st.st_gid
        os.chown(path, uid, gid)
    except (KeyError, OSError, ImportError):
        pass


def backup(path: str, suffix: str) -> None:
    """A copy of a file about to change, once: an earlier copy is the
    original, never overwritten."""
    if suffix and os.path.isfile(path) and not os.path.exists(path + suffix):
        shutil.copy2(path, path + suffix)
        print(f"Backed up {path} to {path + suffix}")


def remove(path: str) -> bool:
    try:
        os.remove(path)
        return True
    except OSError:
        return False


SAVE_CONFIG_HEADER = "#*# <---------------------- SAVE_CONFIG"


def read_lines(conf: str) -> List[str]:
    try:
        with open(conf, encoding="utf-8") as f:
            return f.read().splitlines(True)
    except (OSError, UnicodeDecodeError):
        return []


def is_header(line: str, section: str) -> bool:
    s = line.strip()
    return s.startswith("[") and s.endswith("]") and \
        s.lower().replace(" ", "") == f"[{section}]".lower().replace(" ", "")


def ensure_section(conf: str, section: str, text: str, owner: str) -> bool:
    """Add a section to a config file if it has none: before Klipper's
    SAVE_CONFIG block when there is one (Klipper refuses anything after
    that header and drops the saved calibration), else at the end."""
    lines = read_lines(conf)
    if any(is_header(ln, section) for ln in lines):
        return False
    at = next((i for i, ln in enumerate(lines)
               if ln.startswith(SAVE_CONFIG_HEADER)), len(lines))
    block = text if text.endswith("\n") else text + "\n"
    before = "".join(lines[:at])
    if before and not before.endswith("\n"):
        before += "\n"
    if before and not before.endswith("\n\n"):
        before += "\n"
    after = "".join(lines[at:])
    return write(conf, before + block + ("\n" + after if after else ""),
                 owner=owner)


def drop_section(conf: str, section: str, owner: str) -> bool:
    """Remove a section from a config file: an [include ...] is its one
    line; anything else runs to the next header or Klipper's SAVE_CONFIG
    block."""
    lines = read_lines(conf)
    if not lines:
        return False
    out: List[str] = []
    skipping = False
    one_line = section.lower().startswith("include ")
    for ln in lines:
        s = ln.strip()
        if is_header(ln, section):
            if one_line:
                continue
            skipping = True
            continue
        if skipping and ((s.startswith("[") and s.endswith("]"))
                         or ln.startswith(SAVE_CONFIG_HEADER)):
            skipping = False
        if not skipping:
            out.append(ln)
    text = "".join(out)
    if text == "".join(lines):
        return False
    return write(conf, text, owner=owner)


def macro_file() -> str:
    return os.path.join(os.path.dirname(__file__), "klipper", KLIPPER_INCLUDE)


def components_dir(a: argparse.Namespace) -> str:
    """moonraker/components (the packaged layout, 2023 on), else a flat
    Moonraker's components (moonraker.py beside it, as on the Creality
    Hi), unless given."""
    if a.components_dir:
        return a.components_dir
    packaged = os.path.join(a.moonraker_dir, "moonraker", "components")
    flat = os.path.join(a.moonraker_dir, "components")
    if not os.path.isdir(packaged) and os.path.isdir(flat):
        return flat
    return packaged


def places(a: argparse.Namespace) -> dict:
    config_dir = os.path.join(a.data_dir, "config")
    comps = components_dir(a)
    return dict(
        shim=os.path.join(comps, SHIM_NAME),
        old_shim=os.path.join(comps, OLD_SHIM_NAME),
        moonraker_conf=a.moonraker_conf
        or os.path.join(config_dir, "moonraker.conf"),
        moonraker_include=os.path.join(a.moonraker_include_dir,
                                       MOONRAKER_INCLUDE)
        if a.moonraker_include_dir else "",
        printer_cfg=a.printer_cfg or os.path.join(config_dir, "printer.cfg"),
        klipper_include=os.path.join(a.klipper_include_dir, KLIPPER_INCLUDE)
        if a.klipper_include_dir else os.path.join(config_dir,
                                                   KLIPPER_INCLUDE),
        store=cfgmod.Store(config_dir, a.data_dir, name=a.name))


def section_text(a: argparse.Namespace) -> str:
    lines = [f"[{SECTION}]",
             "# pushraker (python -m pushraker install); settings are in "
             "pushraker.conf",
             f"name: {a.name}"]
    if a.error_index_url:
        lines.append(f"error_index_url: {a.error_index_url}")
    return "\n".join(lines) + "\n"


def cmd_install(a: argparse.Namespace) -> int:
    p = places(a)
    changed = []
    if p["moonraker_include"] and os.path.realpath(p["moonraker_include"]) \
            == os.path.realpath(p["klipper_include"]):
        print("ERROR: --moonraker-include-dir and the Klipper include "
              "directory are the same; both files are named pushraker.cfg")
        return 1
    if not os.path.isdir(os.path.dirname(p["shim"])):
        print(f"ERROR: no Moonraker components directory at "
              f"{os.path.dirname(p['shim'])} (--moonraker-dir, "
              f"--components-dir)")
        return 1
    if write(p["shim"], SHIM.format(paths=list(a.site_packages)),
             owner=a.owner):
        changed.append(p["shim"])
    # 0.1.x's names: the old shim and section would load the component a
    # second time
    if remove(p["old_shim"]):
        changed.append(f"removed {p['old_shim']}")
    # The old section may live in moonraker.conf even when the new section
    # is installed through an include directory. Leaving it behind asks
    # Moonraker to load the shim we just removed.
    lines = read_lines(p["moonraker_conf"])
    if any(is_header(ln, OLD_SECTION) for ln in lines) or (
            not p["moonraker_include"]
            and not any(is_header(ln, SECTION) for ln in lines)):
        backup(p["moonraker_conf"], a.backup)
    if drop_section(p["moonraker_conf"], OLD_SECTION, a.owner):
        changed.append(f"[{OLD_SECTION}] removed from {p['moonraker_conf']}")
    if p["moonraker_include"]:
        if write(p["moonraker_include"], section_text(a), owner=a.owner):
            changed.append(p["moonraker_include"])
    else:
        if ensure_section(p["moonraker_conf"], SECTION, section_text(a),
                          a.owner):
            changed.append(p["moonraker_conf"])
    if not a.no_klipper:
        with open(macro_file()) as f:
            macros = f.read()
        if write(p["klipper_include"], macros, owner=a.owner):
            changed.append(p["klipper_include"])
        if not a.klipper_include_dir:
            if not any(is_header(ln, f"include {KLIPPER_INCLUDE}")
                       for ln in read_lines(p["printer_cfg"])):
                backup(p["printer_cfg"], a.backup)
            if ensure_section(p["printer_cfg"], f"include {KLIPPER_INCLUDE}",
                              f"[include {KLIPPER_INCLUDE}]\n", a.owner):
                changed.append(p["printer_cfg"])
    store = p["store"]
    if not store.exists():
        s = None
        if a.import_ini:
            s = cfgmod.import_ini(a.import_ini[0], a.import_ini[1],
                                  *(a.import_secrets or ("", "")),
                                  name=a.name)
            if s["enabled"] or s["server"] or s["secret"]:
                print(f"Moving settings from {a.import_ini[0]} "
                      f"[{a.import_ini[1]}] to {store.settings_path}")
            else:
                s = None
        if s is not None:
            store.save(s)
            chown(store.settings_path, a.owner,
                  os.path.dirname(store.settings_path))
            if os.path.exists(store.secrets_path):
                chown(store.secrets_path, a.owner, a.data_dir)
            changed.append(store.settings_path)
        # Otherwise the component writes it at its first start, with the
        # defaults for the printer it finds
    for path in changed:
        print(f"Updated: {path}")
    if not changed:
        print("Already installed; nothing changed.")
    # install.py restarts Moonraker itself and says what to open
    if not os.environ.get("PUSHRAKER_INSTALLER"):
        print(f"pushraker {__version__} is set up. Restart Moonraker"
              + ("" if a.no_klipper else " and Klipper")
              + " to load it, then open the notifications page.")
    return 0


def cmd_uninstall(a: argparse.Namespace) -> int:
    p = places(a)
    removed = []
    for path in (p["shim"], p["old_shim"], p["moonraker_include"],
                 p["klipper_include"]):
        if path and remove(path):
            removed.append(path)
    if not p["moonraker_include"]:
        for section in (SECTION, OLD_SECTION):
            if any(is_header(ln, section)
                   for ln in read_lines(p["moonraker_conf"])):
                backup(p["moonraker_conf"], a.backup)
            if drop_section(p["moonraker_conf"], section, a.owner):
                removed.append(f"[{section}] in {p['moonraker_conf']}")
    if not a.klipper_include_dir and drop_section(
            p["printer_cfg"], f"include {KLIPPER_INCLUDE}", a.owner):
        removed.append(f"[include {KLIPPER_INCLUDE}] in {p['printer_cfg']}")
    if a.purge:
        for path in (p["store"].settings_path, p["store"].secrets_path):
            if remove(path):
                removed.append(path)
    for path in removed:
        print(f"Removed {path}")
    if not removed:
        print("Nothing to remove.")
    if not os.environ.get("PUSHRAKER_INSTALLER"):
        print("Restart Moonraker and Klipper to unload pushraker.")
    return 0


def cmd_status(a: argparse.Namespace) -> int:
    p = places(a)
    print(f"pushraker {__version__}")
    for what, path in (("shim", p["shim"]),
                       ("Moonraker section", p["moonraker_include"]
                        or p["moonraker_conf"]),
                       ("Klipper macros", p["klipper_include"]),
                       ("settings", p["store"].settings_path),
                       ("secrets", p["store"].secrets_path)):
        print(f"  {what}: {path} "
              f"({'present' if os.path.exists(path) else 'missing'})")
    if p["store"].exists():
        print("  " + cfgmod.summary(p["store"].load()))
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    a = parse(sys.argv[1:] if argv is None else argv)
    return {"install": cmd_install, "uninstall": cmd_uninstall,
            "status": cmd_status}[a.command](a)


if __name__ == "__main__":
    sys.exit(main())
