# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-PackageHomePage: https://github.com/noon92/pushraker
# SPDX-FileCopyrightText: Copyright (c) 2026 @noon92

"""Creality's own firmware (the Hi; its CFS is the `box` object, the spool
holder's RFID reader `filament_rack`). Its layers need nothing here: the
generic Printer reads virtual_sdcard's layer fields, which Creality's
Klipper adds.

The model, in this order:
1. Klipper's hostname, "Creality <model>-<last 4 hex of the MAC>" ("Creality
   Hi-78E7"): Creality's default, the model's own name as Creality writes
   it, almost always left as it is.
2. A printer renamed in Creality's UI: Creality's model code in its
   system_config.json (device_info.model_str), looked up in MODEL_CODES
   (kept minimal).
3. "Creality printer".
"""

from __future__ import annotations
import json
import os
import re
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from typing import Any, Dict, Optional, Sequence, Tuple

from . import Frame, Printer

RX_HOSTNAME = re.compile(r"(Creality [A-Za-z0-9 +]+?)-[0-9A-Fa-f]{4}")
# Where Creality's firmware keeps system_config.json: the Hi (and its
# OpenWrt kin) under /mnt/UDISK, the K1 family under /usr/data
SYSTEM_CONFIGS = ("/mnt/UDISK/creality/userdata/config/system_config.json",
                  "/usr/data/creality/userdata/config/system_config.json")
# Creality model codes (device_info.model_str). Only codes seen first-hand
# or in a reliable source, with where:
MODEL_CODES: Dict[str, str] = {
    # The Hi's own system_config.json (model 1013) and its Klipper config
    # folder F018_CR4NU200360C20, on noon's printer, 2026-11-21
    "F018": "Creality Hi",
}


# The camera (WebRTC only, no snapshot address; findings-rev4). Creality's
# `capture 0` makes cam_app append one H.264 frame to the timelapse file;
# the firmware's own ffmpeg decodes it.
CAPTURE = "/usr/bin/capture"
# Creality's own live view (WebRTC): a page at / on port 8000 that plays the
# camera in a plain browser (the Hi; confirmed by noon, 2026-11-21). The
# notification's Live Camera link, on the Printer URL's host
WEBRTC = "/usr/bin/webrtc_local"
LIVE_STREAM = ":8000/"
TIMELAPSE = "/mnt/UDISK/timelapse/main_output.h264"
# delay_image.switch: Creality's timelapse on (1) or off (0); read by its
# Klipper (virtual_sdcard.get_delay_photography_info) for every capture
PRINT_REFER = "/mnt/UDISK/creality/userdata/config/user_print_refer.json"
# Creality's master-server turns the frames into the timelapse video when a
# print ends (`ffmpeg -framerate 15 -i main_output.h264 -vcodec copy ...
# .mp4`; its log, 30 prints on noon's Hi, July-November 2026): 0.4-0.7 s
# after "print state = complete", 8-26 s after a cancel (once the cancel
# macro is done), taking 1.5-6.2 s. No capture burst at the end (its
# Klipper's END_PRINT burst, virtual_sdcard.check_end_print, is commented
# out). For VIDEO_SETTLE seconds after a print, pushraker's capture waits
# for that assembly: after a complete, ASSEMBLY_DUE for it to start, then
# ASSEMBLY_MAX at most for it to end (still running: the last frame, read
# only); and the file is put back only if no assembly started meanwhile.
VIDEO_SETTLE = 60.
ASSEMBLY_DUE = 3.
ASSEMBLY_MAX = 15.
TAIL_BYTES = 2 * 1024 * 1024
DECODE_TIMEOUT = 5.
# `capture` signals cam_app through a FIFO: the frame may land after it
# returns. The file is read and restored once its size has held this long
SETTLE_STEADY = 0.3
SETTLE_MAX = 3.
# One picture at a time (two notifications at once would interleave their
# captures and restores), and one taken this recently is reused
_LOCK = threading.Lock()
REUSE = 5.
# Creality's master-server runs `capture 0` itself at every layer change
# (its log: 0.1-0.8 s after the change; the frame lands up to ~1.2 s after
# that), the same moment pushraker's layer notifications fire. During a
# print with Creality's timelapse on, pushraker takes its own frame too
# (fresh, not the last layer's), but not alongside Creality's: it waits
# until LAYER_HOLD seconds after a layer change, with no `capture` running
# and the file settled, FRAME_WAIT at most, then goes.
LAYER_HOLD = 2.
FRAME_WAIT = 4.
CAMERA_NAME = "Printer camera"
# The live stream (findings-rev5): cam_app sends every frame of the camera's
# own H.264 (1280x720, 15 fps, a keyframe each second; SPS, PPS, IDR) to up
# to 6 clients of this Unix socket, each its own copy: the live page
# (webrtc_local) and Creality's cloud view read it. pushraker reads one
# keyframe as one more client and leaves: nothing written anywhere. cam_app
# sends blocking, so the read never pauses and always ends within
# STREAM_LIMIT seconds (tested on noon's Hi with the live page playing:
# keyframe in 0.07-0.62 s, no frame dropped). It failing (no socket, refused,
# no keyframe in time): `capture 0`, the fallback, with its own rules.
H264_UDS = "/var/run/h264_uds"
STREAM_LIMIT = 2.5
STREAM_MAX = 8 * 1024 * 1024


def _sps_starts(data: bytes) -> list:
    """Where each H.264 sequence parameter set (NAL type 7) starts: every
    `capture` frame is self-contained (SPS, PPS, IDR)."""
    out, i = [], 0
    while True:
        i = data.find(b"\x00\x00\x01", i)
        if i < 0 or i + 3 >= len(data):
            return out
        if data[i + 3] & 0x1F == 7:
            out.append(i - 1 if i > 0 and data[i - 1] == 0 else i)
        i += 3


def _nal_starts(data: bytes) -> list:
    """(where each NAL unit's start code begins, its type)."""
    out, i = [], 0
    while True:
        i = data.find(b"\x00\x00\x01", i)
        if i < 0 or i + 3 >= len(data):
            return out
        out.append((i - 1 if i > 0 and data[i - 1] == 0 else i,
                    data[i + 3] & 0x1F))
        i += 3


def keyframe(data: bytes) -> Tuple[Optional[bytes], int]:
    """The first complete keyframe in a stretch of H.264: from an SPS
    (type 7) through its IDR slices (5), up to the next frame's first unit
    (a P slice 1, an SPS 7 or a delimiter 9). (None, where to keep reading
    from) while incomplete."""
    nals = _nal_starts(data)
    for k, (start, kind) in enumerate(nals):
        if kind != 7:
            continue
        idr = False
        for at, t in nals[k + 1:]:
            if t == 5:
                idr = True
            elif idr and t in (1, 7, 9):
                return data[start:at], 0
        return None, start
    # No SPS yet: keep only a possible partial start code
    return None, max(0, len(data) - 4)


def last_frame(data: bytes) -> Optional[bytes]:
    """The last self-contained frame (from the last SPS) of raw H.264."""
    starts = _sps_starts(data)
    return data[starts[-1]:] if starts else None


class Creality(Printer):
    name = "creality"
    model_name = "Creality printer"
    system_configs: Sequence[str] = SYSTEM_CONFIGS
    capture_bin = CAPTURE
    # Its pictures while printing are its own, one per layer change
    frame_note = "Creality takes one per layer"
    webrtc_bin = WEBRTC
    h264_uds = H264_UDS
    # Fluidd, served by Creality's nginx on 4408 (the Hi; its port 80 is
    # Creality's own web-server: 404 at "/")
    web_page = "http://{host}:4408/"
    web_page_name = "Fluidd"
    timelapse = TIMELAPSE
    print_refer = PRINT_REFER
    proc = "/proc"

    def __init__(self, objects: Sequence[str]) -> None:
        super().__init__(objects)
        # The firmware's own ffmpeg (the Hi has one): no ffmpeg, no camera
        self.ffmpeg = shutil.which("ffmpeg") or (
            "/usr/bin/ffmpeg" if os.path.exists("/usr/bin/ffmpeg") else None)

    # -- the camera --

    def cameras(self) -> Dict[str, Dict[str, str]]:
        if self.ffmpeg and os.path.exists(self.capture_bin):
            live = LIVE_STREAM if os.path.exists(self.webrtc_bin) else ""
            return {CAMERA_NAME: {"snapshot": "printer:camera",
                                  "stream": live}}
        return {}

    def timelapse_on(self) -> bool:
        """Creality's timelapse switch; on when it can't be read (then the
        timelapse file is never touched during a print)."""
        try:
            with open(self.print_refer, encoding="utf-8") as f:
                data = json.load(f)
            return bool(int((data.get("delay_image") or {})
                            .get("switch", 1)))
        except (OSError, ValueError, TypeError, AttributeError):
            return True

    def assembling(self) -> bool:
        """Whether Creality is making the timelapse video (a process, its
        ffmpeg, reading the timelapse file; `capture` aside)."""
        name = os.path.basename(self.timelapse).encode()
        try:
            pids = [p for p in os.listdir(self.proc) if p.isdigit()]
        except OSError:
            return False
        for pid in pids:
            try:
                with open(os.path.join(self.proc, pid, "cmdline"),
                          "rb") as f:
                    argv = f.read().split(b"\0")
            except OSError:
                continue
            if os.path.basename(argv[0]) != b"capture" and any(
                    os.path.basename(a) == name for a in argv[1:]):
                return True
        return False

    def _creality_busy(self, exclude: Optional[int] = None) -> bool:
        return self.capturing(exclude) or self.assembling()

    def capturing(self, exclude: Optional[int] = None) -> bool:
        """Whether a `capture` is running (Creality's own, for its
        timelapse; `exclude`: pushraker's own one's pid)."""
        try:
            pids = [p for p in os.listdir(self.proc) if p.isdigit()]
        except OSError:
            return False
        for pid in pids:
            if exclude is not None and pid == str(exclude):
                continue
            try:
                with open(os.path.join(self.proc, pid, "cmdline"),
                          "rb") as f:
                    argv0 = f.read().split(b"\0", 1)[0]
            except OSError:
                continue
            if os.path.basename(argv0) == b"capture":
                return True
        return False

    def snapshot(self, name: str, ctx: Dict[str, Any]
                 ) -> Tuple[Optional[bytes], str]:
        """One picture at a time; the last one again within REUSE seconds."""
        with _LOCK:
            last = getattr(self, "_last_picture", None)
            if last and time.monotonic() - last[0] < REUSE:
                return last[1], ""
            data, why = self._snapshot(ctx)
            if data:
                self._last_picture = (time.monotonic(), data)
            return data, why

    def _snapshot(self, ctx: Dict[str, Any]
                  ) -> Tuple[Optional[bytes], str]:
        """The camera's picture by the printer's state (ctx: "state" =
        print_stats.state, "since_end" = seconds since a print ended or
        None; the component gives a huge number when none ended since it
        started, which the timelapse file's own time then covers):
        - first, always: the current keyframe from the live stream
          (stream_frame), which writes nothing. Failing that:
        - printing with timelapse on: `capture 0` once Creality's own
          capture for a layer change is done (_await_quiet), the timelapse
          file put back only when nothing but pushraker's frame was added
          (capture_frame, guarded). The capture failing: Creality's last
          frame instead, read only, with when it was taken;
        - within VIDEO_SETTLE after a print, with the timelapse file
          there (Creality makes the video from it then): `capture 0`
          once its video is made (_await_assembly), guarded as above;
          the video still being made: the last frame, read only;
        - otherwise (printing with timelapse off, idle, or just ended with
          no file, so no video pending): `capture 0`, then the timelapse
          file put back exactly as it was; never while a `capture` runs.
        None only when neither gives a frame, with the reason."""
        if not self.ffmpeg:
            return None, "no ffmpeg on this printer"
        # The live stream's current keyframe: writes nothing, so the same
        # whatever the printer is doing
        frame, why = self.stream_frame()
        if frame:
            data, why = self.decode(frame)
            if data:
                return data, why
        # The fallback: `capture 0` and Creality's timelapse file
        state = str(ctx.get("state") or "")
        printing = state in ("printing", "paused")
        since = ctx.get("since_end")
        try:
            # Also after a Moonraker restart, which forgets the print
            written = time.time() - os.path.getmtime(self.timelapse)
        except OSError:
            written = None
        just_ended = not printing and any(
            t is not None and t < VIDEO_SETTLE for t in (since, written))
        if printing and self.timelapse_on():
            quiet = self._await_quiet()
            data, why = self.capture_frame(guarded=True, quiet=quiet)
            if data:
                return data, why
            last, _ = self._last_frame_read_only()
            return last if last[0] else (None, why)
        if just_ended and os.path.exists(self.timelapse):
            # Creality makes its video from the file now: once it's made
            why = "the printer is making its timelapse video"
            if self._await_assembly(state, since):
                quiet = self._await_quiet()
                data, why = self.capture_frame(guarded=True, quiet=quiet)
                if data:
                    return data, why
            got, frame_found = self._last_frame_read_only()
            if frame_found:
                return got
            return None, why
        # Idle, timelapse off, or just ended with no file (no video
        # pending): a capture, the file put back exactly
        if self.capturing():
            return None, "the printer is taking a timelapse frame"
        return self.capture_frame()

    def stream_frame(self) -> Tuple[Optional[bytes], str]:
        """One complete keyframe from cam_app's live stream (H264_UDS), as
        one more client: read without pause, closed within STREAM_LIMIT
        seconds whatever happens. Or why there's none."""
        if not os.path.exists(self.h264_uds):
            return None, "no live stream"
        start = time.monotonic()
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        buf = b""
        try:
            sock.settimeout(0.5)
            sock.connect(self.h264_uds)
            while True:
                left = STREAM_LIMIT - (time.monotonic() - start)
                if left <= 0:
                    return None, "no keyframe from the live stream in time"
                sock.settimeout(min(0.5, left))
                try:
                    chunk = sock.recv(262144)
                except socket.timeout:
                    continue
                if not chunk:
                    return None, "the live stream closed"
                buf += chunk
                frame, keep = keyframe(buf)
                if frame:
                    return frame, ""
                buf = buf[keep:]
                if len(buf) > STREAM_MAX:
                    return None, "no keyframe in the live stream"
        except OSError as e:
            return None, f"the live stream: {e}"
        finally:
            sock.close()

    def _last_frame_read_only(self) -> Tuple[Tuple[Optional[bytes], str],
                                             bool]:
        """Creality's newest frame in the timelapse file, decoded, as a
        Frame with when it was taken; and whether there was one."""
        try:
            # The last frame was appended then: when it was taken
            taken: Optional[float] = os.path.getmtime(self.timelapse)
        except OSError:
            taken = None
        frame = self._last_timelapse_frame()
        if frame is None:
            return (None, "no camera frame yet (Creality takes one per "
                    "layer)"), False
        data, why = self.decode(frame)
        return ((Frame(data, taken) if data else data), why), True

    def adjust_status(self, data: Dict[str, Any],
                      status: Dict[str, Dict[str, Any]]) -> None:
        """The generic layer fill, and when virtual_sdcard.layer last
        changed (Creality takes a timelapse frame then)."""
        super().adjust_status(data, status)
        layer = (data.get("virtual_sdcard") or {}).get("layer")
        if layer is not None and layer != getattr(self, "_layer", None):
            self._layer = layer
            if layer:
                self._layer_changed = time.monotonic()

    def _size(self) -> int:
        try:
            return os.path.getsize(self.timelapse)
        except OSError:
            return -1

    def _await_assembly(self, state: str, since: Optional[float]) -> bool:
        """After a print: until Creality's video is made. A print just
        complete, timelapse on: ASSEMBLY_DUE seconds from its end for the
        assembly to start; then until it ends. False when it still runs after
        ASSEMBLY_MAX."""
        start = time.monotonic()
        if state == "complete" and since is not None \
                and since < ASSEMBLY_DUE and self.timelapse_on():
            until = start + ASSEMBLY_DUE - since
            while time.monotonic() < until and not self.assembling():
                time.sleep(0.05)
        while self.assembling():
            if time.monotonic() - start >= ASSEMBLY_MAX:
                return False
            time.sleep(0.1)
        return True

    def _await_quiet(self) -> bool:
        """Until Creality isn't capturing: LAYER_HOLD seconds after a layer
        change, no `capture` running, the timelapse file's size held for
        SETTLE_STEADY. FRAME_WAIT at most; whether it got there."""
        start = time.monotonic()
        last, since = self._size(), start
        while True:
            now = time.monotonic()
            size = self._size()
            if size != last:
                last, since = size, now
            changed = getattr(self, "_layer_changed", None)
            if (changed is None or now - changed >= LAYER_HOLD) \
                    and now - since >= SETTLE_STEADY \
                    and not self._creality_busy():
                return True
            if now - start >= FRAME_WAIT:
                return False
            time.sleep(0.05)

    def _last_timelapse_frame(self) -> Optional[bytes]:
        try:
            size = os.path.getsize(self.timelapse)
            with open(self.timelapse, "rb") as f:
                f.seek(max(0, size - TAIL_BYTES))
                tail = f.read()
        except OSError:
            return None
        return last_frame(tail)

    def capture_frame(self, guarded: bool = False, quiet: bool = True
                      ) -> Tuple[Optional[bytes], str]:
        """`capture 0`, the new frame decoded, the timelapse file restored
        (cut back to its size, or removed if it wasn't there).
        `guarded` (Creality's timelapse recording): restored only when
        exactly one self-contained frame was added and Creality wasn't
        capturing meanwhile (no other `capture`, no video being made from
        the file, no layer change; `quiet`: nor before). Otherwise left as it is: Creality's own frame is
        never cut, the video gets ours as one extra frame at worst."""
        path = self.timelapse
        before = os.path.getsize(path) if os.path.exists(path) else None
        times = (os.stat(path).st_atime, os.stat(path).st_mtime) \
            if before is not None else None
        layer0 = getattr(self, "_layer_changed", None)
        seen = not quiet          # Creality's capture in our window
        failed = ""
        new = b""
        try:
            try:
                proc = subprocess.Popen([self.capture_bin, "0"],
                                        stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL)
                end = time.monotonic() + DECODE_TIMEOUT
                while proc.poll() is None:
                    if guarded and self._creality_busy(exclude=proc.pid):
                        seen = True
                    if time.monotonic() > end:
                        proc.kill()
                        proc.wait()
                        raise subprocess.TimeoutExpired(
                            self.capture_bin, DECODE_TIMEOUT)
                    time.sleep(0.02)
                if proc.returncode:
                    failed = f"exit {proc.returncode}"
            except (OSError, subprocess.TimeoutExpired) as e:
                failed = str(e)
            # Whatever happened, wait for cam_app's write to land, so the
            # restore below takes all of it back
            if self.settle(path, self._creality_busy if guarded else None):
                seen = True
            try:
                with open(path, "rb") as f:
                    f.seek(before or 0)
                    new = f.read()
            except OSError as e:
                if not failed:
                    failed = str(e)
        finally:
            try:
                restore = True
                if guarded:
                    restore = not seen and len(_sps_starts(new)) == 1 \
                        and getattr(self, "_layer_changed", None) == layer0 \
                        and not self._creality_busy() \
                        and self._size() == (before or 0) + len(new)
                if not restore:
                    pass
                elif before is None:
                    if os.path.exists(path):
                        os.remove(path)
                elif os.path.getsize(path) > before:
                    with open(path, "r+b") as f:
                        f.truncate(before)
                    os.utime(path, times)    # as it was, to the second
            except OSError:
                pass
        if failed:
            return None, f"the camera didn't take a picture ({failed})"
        frame = last_frame(new) or (new or None)
        if not frame:
            return None, "the camera took no picture"
        return self.decode(frame)

    @staticmethod
    def settle(path: str, watch: Any = None) -> bool:
        """Until the file's size has held for SETTLE_STEADY seconds (at most
        SETTLE_MAX). `watch`: a check run meanwhile; whether it was ever
        true."""
        def size() -> int:
            try:
                return os.path.getsize(path)
            except OSError:
                return -1
        end = time.monotonic() + SETTLE_MAX
        last, since = size(), time.monotonic()
        seen = False
        while time.monotonic() < end:
            time.sleep(0.05)
            if watch is not None and watch():
                seen = True
            now = size()
            if now != last:
                last, since = now, time.monotonic()
            elif time.monotonic() - since >= SETTLE_STEADY and now >= 0:
                break
        return seen

    def decode(self, h264: bytes) -> Tuple[Optional[bytes], str]:
        """One H.264 frame to a JPEG with the firmware's ffmpeg, at low
        priority, in a temporary folder that is removed again (pictures of
        the room never stay on the printer)."""
        tmp = tempfile.mkdtemp(prefix="pushraker_cam_")
        try:
            src = os.path.join(tmp, "frame.h264")
            out = os.path.join(tmp, "frame.jpg")
            with open(src, "wb") as f:
                f.write(h264)
            r = subprocess.run(
                [str(self.ffmpeg), "-hide_banner", "-loglevel", "error",
                 "-y", "-f", "h264", "-i", src, "-frames:v", "1",
                 "-q:v", "4", out],
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                timeout=DECODE_TIMEOUT,
                preexec_fn=lambda: os.nice(10))
            if r.returncode or not os.path.exists(out):
                err = (r.stderr or b"").decode("utf-8", "replace").strip()
                return None, "ffmpeg couldn't decode the frame" + \
                    (f" ({err[-120:]})" if err else "")
            with open(out, "rb") as f:
                data = f.read()
            return (data, "") if data.startswith(b"\xff\xd8") else \
                (None, "ffmpeg wrote no JPEG")
        except subprocess.TimeoutExpired:
            return None, "decoding the frame took too long"
        except OSError as e:
            return None, f"ffmpeg: {e}"
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @classmethod
    def matches(cls, objects: Sequence[str]) -> bool:
        return "box" in objects or "filament_rack" in objects

    def model_code(self) -> Optional[str]:
        for path in self.system_configs:
            try:
                with open(path, encoding="utf-8") as f:
                    info = json.load(f).get("device_info") or {}
            except (OSError, ValueError, AttributeError):
                continue
            code = str(info.get("model_str") or "").strip()
            if code:
                return code
        return None

    def model(self, hostname: str = "") -> str:
        m = RX_HOSTNAME.fullmatch(hostname.strip())
        if m:
            return m.group(1)
        code = self.model_code()
        return MODEL_CODES.get(code or "", self.model_name)
